/*
 This source file is part of the Swift.org open source project

 Copyright (c) 2014 - 2017 Apple Inc. and the Swift project authors
 Licensed under Apache License v2.0 with Runtime Library Exception

 See http://swift.org/LICENSE.txt for license information
 See http://swift.org/CONTRIBUTORS.txt for Swift project authors
*/

import XCTest

import TSCBasic
import TSCTestSupport


struct ByteSequence: Sequence {
    let bytes16 = [UInt8](repeating: 0, count: 1 << 4)

    func makeIterator() -> ByteSequenceIterator {
        return ByteSequenceIterator(bytes16: bytes16)
    }
}

extension ByteSequence: ByteStreamable {
    func write(to stream: WritableByteStream) {
        stream.write(sequence: self)
    }
}

struct ByteSequenceIterator: IteratorProtocol {
    let bytes16: [UInt8]
    var index: Int
    init(bytes16: [UInt8]) {
        self.bytes16 = bytes16
        index = 0
    }
    mutating func next() -> UInt8? {
        if index == bytes16.count { return nil }
        defer { index += 1 }
        return bytes16[index]
    }
}

class OutputByteStreamPerfTests: XCTestCasePerf {

    func test1MBOfSequence_X10() {
      #if canImport(Darwin)
        let sequence = ByteSequence()
        measure {
            for _ in 0..<10 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 16) {
                    stream.send(sequence)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }

    func test1MBOfByte_X10() {
      #if canImport(Darwin)
        let byte = UInt8(0)
        measure {
            for _ in 0..<10 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 20) {
                    stream.send(byte)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }

    func test1MBOfCharacters_X1() {
      #if canImport(Darwin)
        measure {
            for _ in 0..<1 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 20) {
                    stream.send(Character("X"))
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }

    func test1MBOf16ByteArrays_X100() {
      #if canImport(Darwin)
        // Test writing 1MB worth of 16 byte strings.
        let bytes16 = [UInt8](repeating: 0, count: 1 << 4)
        
        measure {
            for _ in 0..<100 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 16) {
                    stream.send(bytes16)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }
    
    // This should give same performance as 16ByteArrays_X100.
    func test1MBOf16ByteArraySlice_X100() {
      #if canImport(Darwin)
        let bytes32 = [UInt8](repeating: 0, count: 1 << 5)
        // Test writing 1MB worth of 16 byte strings.
        let bytes16 = bytes32.suffix(from: bytes32.count/2)

        measure {
            for _ in 0..<100 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 16) {
                    stream.send(bytes16)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }

    func test1MBOf1KByteArrays_X1000() {
      #if canImport(Darwin)
        // Test writing 1MB worth of 1K byte strings.
        let bytes1k = [UInt8](repeating: 0, count: 1 << 10)
        
        measure {
            for _ in 0..<1000 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 10) {
                    stream.send(bytes1k)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }

    func test1MBOf16ByteStrings_X10() {
      #if canImport(Darwin)
        // Test writing 1MB worth of 16 byte strings.
        let string16 = String(repeating: "X", count: 1 << 4)
        
        measure {
            for _ in 0..<10 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 16) {
                    stream.send(string16)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }

    func test1MBOf1KByteStrings_X100() {
      #if canImport(Darwin)
        // Test writing 1MB worth of 1K byte strings.
        let bytes1k = String(repeating: "X", count: 1 << 10)
        
        measure {
            for _ in 0..<100 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 10) {
                    stream.send(bytes1k)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }
    
    func test1MBOfJSONEncoded16ByteStrings_X10() {
      #if canImport(Darwin)
        // Test writing 1MB worth of JSON encoded 16 byte strings.
        let string16 = String(repeating: "X", count: 1 << 4)
        
        measure {
            for _ in 0..<10 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 16) {
                    stream.writeJSONEscaped(string16)
                }
                XCTAssertEqual(stream.bytes.count, 1 << 20)
            }
        }
      #endif
    }
    
    func testFormattedJSONOutput() {
      #if canImport(Darwin)
        // Test the writing of JSON formatted output using stream operators.
        struct Thing {
            var value: String
            init(_ value: String) { self.value = value }
        }
        let listOfStrings: [String] = (0..<10).map { "This is the number: \($0)!\n" }
        let listOfThings: [Thing] = listOfStrings.map(Thing.init)
        measure {
            for _ in 0..<10 {
                let stream = BufferedOutputByteStream()
                for _ in 0..<(1 << 10) {
                    for string in listOfStrings {
                        stream.send(Format.asJSON(string))
                    }
                    stream.send(Format.asJSON(listOfStrings))
                    stream.send(Format.asJSON(listOfThings, transform: { $0.value }))
                }
                XCTAssertGreaterThan(stream.bytes.count, 1000)
            }
        }
      #endif
    }

    func testJSONToString_X100() {
      #if canImport(Darwin)
        let foo = JSON.dictionary([
            "foo": .string("bar"),
            "bar": .int(2),
            "baz": .array([1, 2, 3].map(JSON.int)),
        ])

        let bar = JSON.dictionary([
            "poo": .array([foo, foo, foo]),
            "foo": .int(1),
        ])

        let baz = JSON.dictionary([
            "poo": .array([foo, bar, foo]),
            "foo": .int(1),
        ])

        let json = JSON.array((0..<100).map { _ in baz })
        measure {
            for _ in 0..<100 {
                let result = json.toString()
                XCTAssertGreaterThan(result.utf8.count, 10)
            }
        }
      #endif
    }
}
